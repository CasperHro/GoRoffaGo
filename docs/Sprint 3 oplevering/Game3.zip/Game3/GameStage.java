public enum GameStage {
    WAITING,
    PROGRAMMING,
    RUNNINGCODE,
    EVALUATING
}
    
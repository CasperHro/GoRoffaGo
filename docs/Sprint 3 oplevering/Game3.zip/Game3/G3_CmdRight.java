import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class G3_CmdRight here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class G3_CmdRight extends G3_Command
{
    public G3_CmdRight()
    {
        super.command = "right";
    }
}

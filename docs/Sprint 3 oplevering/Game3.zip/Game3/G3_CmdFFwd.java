import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class G3_CmdFFwd here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class G3_CmdFFwd extends G3_Command
{
    public G3_CmdFFwd()
    {
        super.command = "ffwd";
    }
}
